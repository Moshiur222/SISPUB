from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.hashers import make_password
from django.core.exceptions import ValidationError
from django.contrib.auth import get_user_model
from django.core.files.storage import default_storage
from django.core.files.base import ContentFile
from django.core.paginator import Paginator
from django.http import JsonResponse
from collections import defaultdict
from django.contrib import messages
from django.utils import timezone
from django.db import transaction
from datetime import datetime
from .models import *
from .utils import *
import random



# home_view start

def home_view(request):
    context = {
        "gellaries": Gellary.objects.all(),
        "videos": Video.objects.all(),
        "hero_areas": HeroArea.objects.all(),
    }
    return render(request, "home/layouts/home.html", context)


def about_view(request):
    return render(request, "home/layouts/about.html", {'about_para': AboutParagraph.objects.all(), "about_albums":AboutAlbum.objects.all(), "company_info": Company_info.objects.all()})

def vision(request):
    vision = Vision.objects.all()
    context = {
        "vision" : vision,
    }
    return render(request, "home/layouts/vision.html", context)

def core_values(request):
    core_values = CoreValues.objects.all()
    context = {
        "core_values" : core_values,
    }
    return render(request, "home/layouts/core_values.html", context)

def mission(request):
    mission = Mission.objects.all()
    context = {
        "mission" : mission,
    }
    return render(request, "home/layouts/mission.html", context)



def founder_view(request):
    founders_list = FoundersInfo.objects.all().order_by('id')

    paginator = Paginator(founders_list, 6)

    page_number = request.GET.get('page')  # may be None or ''
    founders = paginator.get_page(page_number)  # ✅ SAFE

    context = {
        'founders': founders,
        'page_obj': founders
    }
    return render(request, "home/layouts/founder.html", context)


def current_executive_commitee(request):
    commitees_list = SispabExecutiveCom.objects.all().order_by('id')  # QuerySet
    paginator = Paginator(commitees_list, 6)  # 6 cards per page

    page_number = request.GET.get('page')
    commitees = paginator.get_page(page_number)  # SAFE (no crash)

    context = {
        'commitees': commitees,  # for template loop
        'page_obj': commitees    # for pagination buttons
    }
    return render(request, "home/layouts/current_executive_commitee.html", context)

def previous_committee(request):
    commitees_list = PreviousExecutiveCommittee.objects.all().order_by('id')  # QuerySet
    paginator = Paginator(commitees_list, 6)  # 6 members per page

    page_number = request.GET.get('page')
    commitees = paginator.get_page(page_number)  # safe

    context = {
        'commitees': commitees,  # for looping through
        'page_obj': commitees    # for pagination controls
    }
    return render(request, "home/layouts/previous_committee.html", context)

def membership_rules(request):
    rules_titles = MembershipRules.objects.all()
    context = {
        'rules_titles' : rules_titles,
    }
    return render(request, "home/layouts/membership_rules.html", context)


def process_of_members(request):
    return render(request, "home/layouts/process_of_members.html")

def sisbup_secretariat(request):
    return render(request, "home/layouts/sisbup_secretariat.html")


def benefit_od_member(request):
    return render(request, "home/layouts/benefit_of_member.html")

def advisory_council(request):
    return render(request, "home/layouts/advisory_council.html")

def member_resistation(request):
    return render(request, "home/layouts/member_resistation.html")

def login_view(request):
    if request.method == "POST":
        email = request.POST.get("email")
        password = request.POST.get("password")

        if not email or not password:
            messages.error(request, "Email and password are required")
            return render(request, "home/layouts/login.html")

        user = authenticate(request, email=email, password=password)

        if user is not None:
            if user.user_type == 1:
                login(request, user)
                messages.success(request, "Welcome Admin")
                return redirect("dashboard")

            elif user.user_type == 2:
                login(request, user)
                messages.success(request, "Welcome User")
                return redirect("home")

            else:
                messages.error(request, "Unauthorized user type")
                return render(request, "home/layouts/login.html")

        else:
            messages.error(request, "Invalid email or password")

    return render(request, "home/layouts/login.html")

def logout_view(request):
    logout(request)
    messages.success(request, "Logout")
    return redirect('login') 

@login_required
def profile(request):
    aggregator = Aggregator.objects.filter(user=request.user).first()

    context = {
        'aggregator': aggregator,
    }
    
    return render(request, "home/layouts/profile.html", context)


@login_required
def edit_profile(request):
    aggregator = Aggregator.objects.filter(user=request.user).first()

    if not aggregator:
        messages.warning(request, "Profile not found.")
        return redirect('profile')

    if request.method == "POST":
        aggregator.name = request.POST.get("name")
        aggregator.company_name = request.POST.get("company_name")
        aggregator.designation = request.POST.get("designation")
        aggregator.mobile = request.POST.get("mobile")
        aggregator.phone = request.POST.get("phone")
        aggregator.brtc_licence_no = request.POST.get("brtc_licence_no")
        aggregator.tread_licence_no = request.POST.get("tread_licence_no")
        aggregator.n_id = request.POST.get("n_id")
        aggregator.address = request.POST.get("address")

        if request.FILES.get("image"):
            aggregator.image = request.FILES.get("image")

        if request.FILES.get("appoinment_letter"):
            aggregator.appoinment_letter = request.FILES.get("appoinment_letter")

        # Handle CV upload
        if request.FILES.get("cv"):
            aggregator.cv = request.FILES.get("cv")

        aggregator.save()
        messages.success(request, "Profile updated successfully.")
        return redirect("profile")

    context = {
        "aggregator": aggregator
    }

    return render(request, "home/layouts/edit_profile.html", context)


# ================== REGISTRATION VIEW ==================
def registration_view(request):

    # -------- OTP VERIFY / RESEND --------
    if request.method == "POST" and ("otp_code" in request.POST or "resend_otp" in request.POST):

        mobile = normalize_phone(request.POST.get("mobile"))
        reg_data = request.session.get('pending_registration')

        # ✅ FIXED SESSION ISSUE
        if not reg_data:
            messages.error(request, "Session expired. Please register again.")
            return redirect("registration")

        # ✅ যদি mobile change করে
        if reg_data.get('mobile') != mobile:
            reg_data['mobile'] = mobile
            request.session['pending_registration'] = reg_data

        # -------- RESEND OTP --------
        if "resend_otp" in request.POST:
            new_otp = str(random.randint(100000, 999999))

            reg_data['otp'] = hash_otp(new_otp)
            reg_data['otp_created_at'] = timezone.now().isoformat()
            request.session['pending_registration'] = reg_data

            # ✅ SEND SMS
            if send_sms(mobile, f"Your OTP is {new_otp}"):
                messages.success(request, "OTP resent successfully.")
            else:
                messages.error(request, "Failed to resend OTP.")

            return render(request, "home/layouts/registration.html", {
                "otp_sent": True,
                "mobile": mobile
            })

        # -------- VERIFY OTP --------
        user_otp = request.POST.get("otp_code")

        otp_time = timezone.datetime.fromisoformat(reg_data.get('otp_created_at'))

        if (timezone.now() - otp_time).total_seconds() > 60:
            messages.error(request, "OTP expired. Please click Resend OTP.")
            return render(request, "home/layouts/registration.html", {
                "otp_sent": True,
                "mobile": mobile
            })

        if hash_otp(user_otp) != reg_data.get('otp'):
            messages.error(request, "Invalid OTP.")
            return render(request, "home/layouts/registration.html", {
                "otp_sent": True,
                "mobile": mobile
            })

        # -------- SAVE DATA --------
        TempMember.objects.create(
            company_name=reg_data.get("company_name"),
            person_name=reg_data.get("person_name"),
            designation=reg_data.get("designation"),
            email=reg_data.get("email"),
            mobile=reg_data.get("mobile"),
            phone=reg_data.get("phone"),
            password=reg_data.get("password"),
            brtc_licence_no=reg_data.get("brtc_licence_no"),
            is_aggregator=reg_data.get("is_aggregator"),
            n_id=reg_data.get("n_id"),
            address=reg_data.get("address"),
            cv=reg_data.get("cv_file"),
            appoinment_letter=reg_data.get("app_file"),
            otp=reg_data.get("otp"),
            otp_created_at=otp_time,
            status='pending'
        )

        del request.session['pending_registration']

        messages.success(request, "Registration successful! Wait for approval.")
        return redirect("registration")

    # -------- INITIAL FORM --------
    elif request.method == "POST":

        password = request.POST.get("password")
        confirm_password = request.POST.get("confirm_password")

        if password != confirm_password:
            messages.error(request, "Passwords do not match.")
            return redirect("registration")

        mobile = normalize_phone(request.POST.get("mobile"))
        email = request.POST.get("email")

        if not mobile:
            messages.error(request, "Invalid mobile number format.")
            return redirect("registration")

        if TempMember.objects.filter(mobile=mobile).exists():
            messages.error(request, "Phone already registered.")
            return redirect("registration")

        otp = str(random.randint(100000, 999999))

        cv = request.FILES.get("cv")
        app_letter = request.FILES.get("appoinment_letter")

        cv_path = default_storage.save(f"cv/{cv.name}", ContentFile(cv.read())) if cv else None
        app_path = default_storage.save(f"letter/{app_letter.name}", ContentFile(app_letter.read())) if app_letter else None

        # SAVE SESSION
        request.session['pending_registration'] = {
            "company_name": request.POST.get("company_name"),
            "person_name": request.POST.get("person_name"),
            "designation": request.POST.get("designation"),
            "n_id": request.POST.get("n_id"),
            "cv_file": cv_path,
            "app_file": app_path,
            "email": email,
            "mobile": mobile,
            "phone": request.POST.get("phone"),
            "password": make_password(password),
            "brtc_licence_no": request.POST.get("brtc_licence_no", "").strip(),
            "is_aggregator": 'Yes' if request.POST.get("is_aggregator") == 'yes' else 'No',
            "address": request.POST.get("address"),
            "otp": hash_otp(otp),
            "otp_created_at": timezone.now().isoformat()
        }

        # ✅ SEND OTP
        if send_sms(mobile, f"Your OTP is {otp}"):
            messages.success(request, "OTP sent successfully.")
        else:
            messages.error(request, "Failed to send OTP.")

        return render(request, "home/layouts/registration.html", {
            "otp_sent": True,
            "mobile": mobile
        })

    return render(request, "home/layouts/registration.html", {"otp_sent": False})


def search(request):
    member_id = request.GET.get('member_id')
    member = None
    if member_id:
        try:
            member = Aggregator.objects.get(member_id=member_id)
        except Aggregator.DoesNotExist:
            member = None

    context = {
        'member': member,
        'member_id': member_id
    }
    return render(request, "home/layouts/search_result.html", context)





def meeting_calls(request):
    now = timezone.localtime()

    upcoming_list = MeetingTitle.objects.filter(expire_date__gt=now).order_by('expire_date')
    previous_list = MeetingTitle.objects.filter(expire_date__lte=now).order_by('-expire_date')

    # Pagination: 6 meetings per page
    upcoming_page_number = request.GET.get('upcoming_page')
    previous_page_number = request.GET.get('previous_page')

    upcoming_paginator = Paginator(upcoming_list, 6)
    previous_paginator = Paginator(previous_list, 6)

    upcoming_meetings = upcoming_paginator.get_page(upcoming_page_number)
    previous_meetings = previous_paginator.get_page(previous_page_number)

    return render(request, "home/layouts/meeting_calls.html", {
        'upcoming_meetings': upcoming_meetings,
        'previous_meetings': previous_meetings
    })

User = get_user_model()

def get_aggregator_info(request):
    phone = request.GET.get('phone', '').strip()

    if phone.startswith("+880"):
        phone = phone[3:]
    elif phone.startswith("880"):
        phone = phone[2:]

    try:
        aggregator = Aggregator.objects.select_related('user').filter(phone=phone).first()

        if aggregator:
            data = {
                'is_aggregator': "Yes" if aggregator.is_aggregator else "No",
                'company_name': aggregator.company_name,
                'name': aggregator.name,
                'no_of_person': getattr(aggregator, 'no_of_person', 1),
                'email': aggregator.user.email if aggregator.user else "",
            }
            return JsonResponse({'exists': True, 'data': data})

        return JsonResponse({'exists': False, 'data': {}})

    except Exception as e:
        return JsonResponse({'exists': False, 'error': str(e)}, status=500)
    

def meeting_call(request, id):
    last_title = get_object_or_404(MeetingTitle, id=id)

    context_data = {
        'company_name': '', 'name': '', 'no_of_person': '',
        'phone': '', 'email': '', 'payment_method': '', 'transection_id': '',
    }

    if request.method == 'POST':

        for field in context_data:
            context_data[field] = request.POST.get(field, '').strip()

        phone = context_data['phone']

        # ✅ Check member exists
        if not Aggregator.objects.filter(phone__icontains=phone[-10:]).exists():
            messages.error(request, "Registration failed: Phone number not found in member list.")
            return render(request, 'home/layouts/meeting_call.html', {'title': last_title, **context_data})

        try:
            no_of_person = int(context_data['no_of_person'])
            total_price = (last_title.amount or 0) * no_of_person

            # ✅ Save Data
            MeetingCall.objects.create(
                title=last_title,
                company_name=context_data['company_name'],
                name=context_data['name'],
                no_of_person=no_of_person,
                phone=phone,
                email=context_data['email'],
                payment_method=context_data['payment_method'],
                transection_id=context_data['transection_id'],
                amount=total_price
            )

            # ✅ SEND CONFIRMATION SMS
            message = f"""
Dear {context_data['name']},
Congatulations! Your meeting registration is successful.

Event: {last_title.title}
Persons: {no_of_person}
Amount: {total_price} BDT

Thank you.
"""

            if send_sms(phone, message):
                messages.success(request, "Submitted successfully! SMS sent.")
            else:
                messages.warning(request, "Submitted successfully! কিন্তু SMS যায়নি।")

            return redirect('meeting_call', id=last_title.id)

        except Exception as e:
            messages.error(request, f"Error: {e}")

    return render(request, 'home/layouts/meeting_call.html', {'title': last_title, **context_data})

def contact_view(request):
    
    return render(request, "home/layouts/contact_page.html")


def blog_view(request):
    blogs = Blog.objects.all().order_by('-date')

    return render(request, "home/layouts/blog_page.html", {
        "blogs": blogs
    })
    
def news_view(request):
    newses = News.objects.all().order_by('-date')

    paginator = Paginator(newses, 9)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)

    return render(request, "home/layouts/news.html", {
        "page_obj": page_obj
    })

def news_detail_view(request, id):
    news = get_object_or_404(News, id=id)
    return render(request, "home/layouts/news_detail.html", { "news": news })


def view_more(request, id):
    blog = get_object_or_404(Blog, id=id)
    return render(request, "home/layouts/view_more_blog_details.html", {"blog": blog})

def complain_view(request):
    aggregators = Aggregator.objects.all()

    if request.method == "POST":
        try:
            aggregator_id = request.POST.get("aggregator")
            aggregator = Aggregator.objects.get(id=aggregator_id) if aggregator_id else None

            complain = ComplainList(
                name=request.POST.get("name"),
                email=request.POST.get("email"),
                phone=request.POST.get("phone"),
                aggregator=aggregator,
                issue=request.POST.get("issue"),
                suggestion=request.POST.get("suggestion"),
            )
            complain.full_clean()
            complain.save()

            messages.success(request, "Your complain has been submitted successfully!")
            return redirect("complain")

        except ValidationError as e:

            for field, errors in e.message_dict.items():
                for error in errors:
                    messages.error(request, f"{field}: {error}")
        except Aggregator.DoesNotExist:
            messages.error(request, "Selected aggregator does not exist.")

    return render(request, "home/layouts/complain.html", {"aggregators": aggregators})



def media_view(request):
    all_media = PhotoGallery.objects.all().order_by('year')
    
    media_by_year = {}
    for media in all_media:
        media_by_year.setdefault(media.year, []).append(media)

    return render(request, "home/layouts/media_page.html", {'media_by_year': media_by_year})

def photo_gallery(request, id):
    album = get_object_or_404(PhotoAlbum, id=id)
    all_photos_list = album.photos.all().order_by('-id')  # latest first

    paginator = Paginator(all_photos_list, 9)  # 9 photos per page
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)

    context = {
        'album': album,
        'page_obj': page_obj
    }
    return render(request, "home/layouts/photo_gallery.html", context)


def photos(request):
  
    albums_list = PhotoAlbum.objects.all() 

    paginator = Paginator(albums_list, 9)  # Show 9 albums per page
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)

    context = {
        'page_obj': page_obj
    }
    return render(request, "home/layouts/gallery.html", context)




def membership_list(request):
    members = Aggregator.objects.all().order_by('company_name')
    
    # Add pagination - 12 items per page
    paginator = Paginator(members, 12)  # Show 12 members per page
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    
    context = {
        "members": members, 
        "page_obj": page_obj, 
    }
    
    return render(request, "home/layouts/membership_lists.html", context)


def events_view(request):
    events = Events.objects.all()
    events_meetings = Events_Meetings.objects.all()
    context = {
        "events": events,
        "events_meetings": events_meetings
    }
    return render(request, "home/layouts/events.html", context)


def video_gallery(request):
    # Fetch events and meetings
    events = Events.objects.all().order_by('-id')
    events_meetings = Events_Meetings.objects.all().order_by('-id')

    # Combine videos into a single list with a uniform structure
    videos = []

    for event in events:
        if getattr(event, 'embed_url_1', None):
            videos.append({'title': event.title, 'url': event.embed_url_1})
        if getattr(event, 'embed_url_2', None):
            videos.append({'title': event.title, 'url': event.embed_url_2})

    for meeting in events_meetings:
        if getattr(meeting, 'video_link', None):  # Replace with your actual field in Events_Meetings
            videos.append({'title': meeting.title, 'url': meeting.video_link})

    # Pagination
    paginator = Paginator(videos, 6)  # 6 videos per page
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)

    context = {
        'page_obj': page_obj
    }
    return render(request, "home/layouts/video_gallery.html", context)


def meetings(request):

    events_meetings = Events_Meetings.objects.all().order_by('title')


    grouped_events = defaultdict(list)
    for event in events_meetings:
        grouped_events[event.title].append(event)


    grouped_events = dict(grouped_events)

    context = {
        "grouped_events": grouped_events,
    }
    return render(request, "home/layouts/meetings.html", context)


def career(request):
    career_list = Career.objects.all().order_by('-id')  # newest first
    paginator = Paginator(career_list, 6)  # show 6 careers per page
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)

    context  = {
        'page_obj': page_obj
    }
    return render(request, "home/layouts/career.html", context)

#home_view end


# admin_view start
@login_required
def dashboard(request):
    return render (request, "admin/pages/dashboard.html")

@login_required
def home_details(request):
    context = {
        "all_company_info" : Company_info.objects.all(),
        "videos": Video.objects.all(), 
        "hero_areas": HeroArea.objects.all(),
    }
    return render (request, 'admin/pages/home_details.html', context)

@login_required
def company_info_input(request):

    try:
        company = Company_info.objects.get(id=1)
    except Company_info.DoesNotExist:
        company = None

    if request.method == "POST":
        company_name = request.POST.get("company_name")
        phone = request.POST.get("phone")
        email = request.POST.get("email")
        office_hours = request.POST.get("office_hours")
        friday = request.POST.get("friday")
        house_no = request.POST.get("house_no")
        block = request.POST.get("block")
        district = request.POST.get("district")
        cirtificate = request.POST.get("cirtificate")
        country = request.POST.get("country")

        if company is None:
            company = Company_info.objects.create(
                company_name=company_name,
                phone=phone,
                email=email,
                office_hours=office_hours,
                friday=friday,
                house_no=house_no,
                block=block,
                district=district,
                cirtificate=cirtificate,
                country=country
            )
        else:
            company.company_name = company_name
            company.phone = phone
            company.email = email
            company.office_hours = office_hours
            company.friday = friday
            company.house_no = house_no
            company.block = block
            company.district = district
            company.country = country
            company.save()

        messages.success(request, "Company information updated successfully!")
        return redirect("company_info_input")

    return render(request, "admin/pages/company_info_input.html", {"company": company})


@login_required
def video_input(request, id):
    video = get_object_or_404(Video, id=id)

    if request.method == "POST":
        video.title = request.POST.get("title")
        video.url = request.POST.get("url")
        video.description = request.POST.get("description")
        video.save()

        messages.success(request, "Video updated successfully!")
        return redirect("video_input", video.id)

    return render(request, "admin/pages/video_input.html", { "video": video })

@login_required
def gallry_input(request):
    if request.method == "POST":
        g_name = request.POST.get("gellary_name")
        year = request.POST.get("year")
        description = request.POST.get("description")
        image = request.FILES.get("image")
        image1 = request.FILES.get("image1")
        image2 = request.FILES.get("image2")

        g = Gellary.objects.create(
            gellary_name=g_name,
            year=year,
            description=description,
            image=image,
            image1=image1,
            image2=image2,
        )
        
        messages.success(request, " Photo has been added successfully!")
        return redirect("gallry_input")  
    current_year = datetime.now().year
    return render(request, "admin/pages/gallry_input.html", {'year_list': range(current_year, current_year - 30, -1), })

@login_required
def gallry_update(request, gellary_id):
    gallery = get_object_or_404(Gellary, id=gellary_id)

    if request.method == "POST":
        gallery.gellary_name = request.POST.get("gellary_name")

        year = request.POST.get("year")
        gallery.year = int(year) if year else None

        gallery.description = request.POST.get("description")

        if request.FILES.get("image"):
            gallery.image = request.FILES.get("image")
        if request.FILES.get("image1"):
            gallery.image1 = request.FILES.get("image1")
        if request.FILES.get("image2"):
            gallery.image2 = request.FILES.get("image2")

        gallery.save()
        messages.success(request, "Updated Successfully")
        return redirect("gallry_update", gellary_id=gallery.id)

    current_year = datetime.now().year

    context = {
        "galleries": gallery,
        "year_list": range(current_year, current_year - 30, -1),
    }

    return render(request, "admin/pages/gallry_update.html", context)


@login_required
def gallry_delete(request, gellary_id):
    gallery = get_object_or_404(Gellary, id=gellary_id)
    if request.method == "POST":
        gallery.delete()
        messages.success(request, 'Photo deleted Succesfully')
        return redirect("home_details")
    return render(request, "admin/pages/home_details.html", {"gallery": gallery})

@login_required
def hero_area_input(request):
    return render (request, 'admin/pages/hero_area_input.html')

@login_required
def hero_area_update(request, id):
    hero_area = get_object_or_404(HeroArea, id=id)

    if request.method == "POST":
        hero_area.tittle = request.POST.get("tittle")
        hero_area.descriptions = request.POST.get("descriptions")

        if request.FILES.get("image"):
            hero_area.image = request.FILES.get("image")

        hero_area.save()

        messages.success(request, "Updated Successfully")
        return redirect("hero_area_input")

    return render(
        request,
        "admin/pages/hero_area_input.html",
        {"hero": hero_area} 
    )

@login_required
def about_details(request):
    context = {
        'about_paragraph': AboutParagraph.objects.all(),
        'about_albums': AboutAlbum.objects.all(),
        'vision': Vision.objects.all(),
        'missions': Mission.objects.all(),
        'core_values': CoreValues.objects.all(),
    }
    return render(request, "admin/pages/about_details.html", context)


@login_required
def update_story(request, id):
    story = get_object_or_404(AboutParagraph, id=id)

    if request.method == "POST":
        title = request.POST.get("title")
        descriptions = request.POST.get("descriptions")

        if not title:
            messages.error(request, "Title cannot be empty")
            return render(request, "admin/pages/update_story.html", {"story": story})

        story.title = title
        story.descriptions = descriptions
        story.save()
        messages.success(request,'Story has been Updated')
        return redirect("update_story", id=story.id)

    return render(request, "admin/pages/update_story.html", {"story": story})

@login_required
def admin_vision(request):
    vision = Vision.objects.all()
    context = {
        'vision' : vision
    }
    return render(request, "admin/pages/vision.html", context)

@login_required
def update_vision(request, id):
     # Fetch the CoreValues object
    vision = get_object_or_404(Vision, id=id)

    if request.method == "POST":
        title = request.POST.get("title")
        descriptions = request.POST.get("descriptions")

        if not title:
            messages.error(request, "Title cannot be empty")
            return render(request, "admin/pages/update_vision.html", {"vision": vision})

        # Update fields
        vision.title = title
        vision.descriptions = descriptions

        # Handle image upload
        if request.FILES.get("image"):
            vision.image = request.FILES.get("image")

        vision.save()
        messages.success(request, "Vision has been updated successfully!")

        # Redirect to the list page after update
        return redirect("update_vision", id=vision.id)

    return render(request, "admin/pages/update_vision.html", {"vision": vision})

@login_required
def admin_mission(request):
    mission = Mission.objects.all()
    context = {
        'mission' : mission
    }
    return render(request, "admin/pages/mission.html", context)

@login_required
def update_mission(request, id):
     # Fetch the CoreValues object
    mission = get_object_or_404(Mission, id=id)

    if request.method == "POST":
        title = request.POST.get("title")
        descriptions = request.POST.get("descriptions")

        if not title:
            messages.error(request, "Title cannot be empty")
            return render(request, "admin/pages/update_vision.html", {"mission": mission})

        # Update fields
        mission.title = title
        mission.descriptions = descriptions

        # Handle image upload
        if request.FILES.get("image"):
            mission.image = request.FILES.get("image")

        mission.save()
        messages.success(request, "Vision has been updated successfully!")

        # Redirect to the list page after update
        return redirect("update_mission", id=mission.id)

    return render(request, "admin/pages/update_mission.html", {"mission": mission})

@login_required
def admin_core_values(request):
    core_values = CoreValues.objects.all()
    context = {
        'core_values': core_values
    }
    return render(request, "admin/pages/core_values.html", context)

@login_required
def update_core_values(request, id):
    # Fetch the CoreValues object
    core_value = get_object_or_404(CoreValues, id=id)

    if request.method == "POST":
        title = request.POST.get("title")
        descriptions = request.POST.get("descriptions")

        if not title:
            messages.error(request, "Title cannot be empty")
            return render(request, "admin/pages/update_core_values.html", {"core_value": core_value})

        # Update fields
        core_value.title = title
        core_value.descriptions = descriptions

        # Handle image upload
        if request.FILES.get("image"):
            core_value.image = request.FILES.get("image")

        core_value.save()
        messages.success(request, "Core Value has been updated successfully!")

        # Redirect to the list page after update
        return redirect("admin_core_values")

    # Render the update form
    return render(request, "admin/pages/update_core_values.html", {"core_value": core_value})

@login_required
def album_input(request):
    if request.method == "POST":
        title = request.POST.get("title")
        image_1 = request.FILES.get("image_1")
        image_2 = request.FILES.get("image_2")
        image_3 = request.FILES.get("image_3")
        descriptions = request.POST.get("descriptions")

        g = AboutAlbum.objects.create(
            title=title,
            image_1=image_1,
            image_2=image_2,
            image_3=image_3,
            descriptions=descriptions,
        )
        messages.success(request,'Photo hase been Uploaded')
        return redirect("album_input")  

    return render(request, "admin/pages/album_input.html")

@login_required
def album_update(request, id):
    about_albums = get_object_or_404(AboutAlbum, id=id)

    if request.method == "POST":
        about_albums.title = request.POST.get("title")
        if request.FILES.get("image_1"):
            about_albums.image_1 = request.FILES.get("image_1")
        if request.FILES.get("image_2"):
            about_albums.image_2 = request.FILES.get("image_2")
        if request.FILES.get("image_3"):
            about_albums.image_3 = request.FILES.get("image_3")
        about_albums.descriptions = request.POST.get("descriptions")
        about_albums.save()
        messages.success(request, 'Photo has been Updated')
        return redirect("album_update", id=about_albums.id)

    return render(request, "admin/pages/album_update.html", {"about_albums": about_albums})

@login_required
def album_delete(request, id):
    about_albums = get_object_or_404(AboutAlbum, id=id)
    if request.method == "POST":
        about_albums.delete()
        messages.success(request,'Photo has been Deleted')
        return redirect("about_details")
    return render(request, "admin/pages/about_details.html", {"about_albums": about_albums})




@login_required
def co_sponsers(request):

    if request.method == "POST":
        image_1 = request.FILES.get("image_1")
        image_2 = request.FILES.get("image_2")
        image_3 = request.FILES.get("image_3")
        image_4 = request.FILES.get("image_4")
        image_5 = request.FILES.get("image_5")

        g = Co_sponsers.objects.create(
            image_1=image_1,
            image_2=image_2,
            image_3=image_3,
            image_4=image_4,
            image_5=image_5,
        )
        messages.success(request,'Co-ponser has been created')
        return redirect("co_sponsers")  

    return render(request, "admin/pages/co_sponsers.html")


@login_required
def sponser_update(request, id):
    sponsers = get_object_or_404(Co_sponsers, id=id)

    if request.method == "POST":
        if request.FILES.get("image_1"):
            sponsers.image_1 = request.FILES.get("image_1")

        if request.FILES.get("image_2"):
            sponsers.image_2 = request.FILES.get("image_2")

        if request.FILES.get("image_3"):
            sponsers.image_3 = request.FILES.get("image_3")

        if request.FILES.get("image_4"):
            sponsers.image_4 = request.FILES.get("image_4")

        if request.FILES.get("image_5"):
            sponsers.image_5 = request.FILES.get("image_5")
        sponsers.save()
        messages.success(request,'Co-sposer has been Updated')
        return redirect("sponser_update", id=sponsers.id)

    return render(request, "admin/pages/sponser_update.html", {"sponsers": sponsers})

@login_required
def sponser_delete(request, id):
    sponsers = get_object_or_404(Co_sponsers, id=id)
    if request.method == "POST":
        sponsers.delete()
        messages.success(request,'Co-sponser has been deleted')
        return redirect("about_details")





@login_required
def sispab_founders(request):
    founders_info = FoundersInfo.objects.all()
    context = {
        'founders_info': founders_info
    }
    return render(request, "admin/pages/sispab_founders.html", context)
@login_required
def add_founder(request):
    if request.method == "POST":
        founder_name = request.POST.get("founder_name")
        designation = request.POST.get("designation")
        company = request.POST.get("company")
        founder_image = request.FILES.get("founder_image")
       

        g = FoundersInfo.objects.create(
            founder_name=founder_name,
            designation=designation,
            company=company,
            founder_image=founder_image,
        )
        messages.success(request,'Fouduner has been created')
        return redirect("add_founder")  

    return render(request, "admin/pages/add_founder.html")
@login_required
def founder_update(request, id):
    info = get_object_or_404(FoundersInfo, id=id)

    if request.method == "POST":
        info.founder_name = request.POST.get("founder_name")
        info.designation = request.POST.get("designation")
        info.company = request.POST.get("company")
        if request.FILES.get("founder_image"):
            info.founder_image = request.FILES.get("founder_image")
        info.save()
        messages.success(request,'Founder has been Updated')
        return redirect("founder_update",  id=info.id)

    return render(request, "admin/pages/founder_update.html", {"info": info})

@login_required
def founder_delete(request, id):
    info = get_object_or_404(FoundersInfo, id=id)
    if request.method == "POST":
        info.delete()
        messages.success(request,'Founder has been Deleted')
        return redirect("sispab_founders")
    return render(request, "admin/pages/sispab_founders.html", {"info's": info})




@login_required
def sispab_executive_com(request):
    sispab_executive_com = SispabExecutiveCom.objects.all()
    context = {
        'sispab_executive_com_info': sispab_executive_com
    }
    return render(request, "admin/pages/sispab_executive_com.html", context)

@login_required
def add_sispab_executive_com(request):
    if request.method == "POST":
        name = request.POST.get("name")
        position = request.POST.get("position")
        image = request.FILES.get("image")

        SispabExecutiveCom.objects.create(
            name=name,
            position=position,
            image=image
        )
        messages.success(request, 'Created Successfully')
        return redirect("add_sispab_executive_com")

    return render(request, "admin/pages/add_sispab_executive_com.html")

@login_required
def sispab_executive_com_update(request, id):
    info = get_object_or_404(SispabExecutiveCom, id=id)

    if request.method == "POST":
        info.name = request.POST.get("name")
        info.position = request.POST.get("position")
        if request.FILES.get("image"):
            info.image = request.FILES.get("image")
        info.save()
        messages.success(request,'Updated Successfully')
        return redirect("sispab_executive_com_update",  id=info.id)

    return render(request, "admin/pages/sispab_executive_com_info.html", {"info": info})

@login_required
def sispab_executive_com_delete(request, id):
    info = get_object_or_404(SispabExecutiveCom, id=id)
    if request.method == "POST":
        info.delete()
        messages.success(request,'Deleted Successfully')
        return redirect("sispab_executive_com")
    return render(request, "admin/pages/sispab_executive_com.html", {"info's": info})

@login_required
def previous_executive_committee(request):
    previous_executive_committee = PreviousExecutiveCommittee.objects.all()
    context = {
        'previous_executive_committee_info': previous_executive_committee
    }
    return render(request, "admin/pages/previous_executive_committee.html", context)

@login_required
def add_previous_executive_committee(request):
    if request.method == "POST":
        name = request.POST.get("name")
        position = request.POST.get("position")
        designation = request.POST.get("designation")
        company = request.POST.get("company")
        image = request.FILES.get("image")

        PreviousExecutiveCommittee.objects.create(
            name=name,
            position=position,
            designation=designation,
            company=company,
            image=image
        )
        messages.success(request, 'Created Successfully')
        return redirect("add_previous_executive_committee")

    return render(request, "admin/pages/add_previous_executive_committee.html")

@login_required
def previous_executive_committee_update(request, id):
    info = get_object_or_404(PreviousExecutiveCommittee, id=id)

    if request.method == "POST":
        info.name = request.POST.get("name")
        info.position = request.POST.get("position")
        info.designation = request.POST.get("designation")
        info.company = request.POST.get("company")
        if request.FILES.get("image"):
            info.image = request.FILES.get("image")
        info.save()
        messages.success(request,'Updated Successfully')
        return redirect("previous_executive_committee_update",  id=info.id)

    return render(request, "admin/pages/previous_executive_committee_update.html", {"info": info})

@login_required
def previous_executive_committee_delete(request, id):
    info = get_object_or_404(PreviousExecutiveCommittee, id=id)
    if request.method == "POST":
        info.delete()
        messages.success(request,'Deleted Successfully')
        return redirect("previous_executive_committee")
    return render(request, "admin/pages/previous_executive_committee.html", {"info's": info})

@login_required
def AdminEvents(request):
    events = Events.objects.all()
    meetings = Events_Meetings.objects.all()
    context = {
        'meetings': meetings,
        'events': events
    }
    return render(request, "admin/pages/events.html", context)


@login_required
def admin_video_gallery(request):
    events = Events.objects.all()
    meetings = Events_Meetings.objects.all()
    context = {
        'meetings': meetings,
        'events': events
    }
    return render(request, "admin/pages/admin_video_gallery.html", context)


#video gellary start

@login_required
def upload_video(request):
    if request.method == "POST":
        title_text = request.POST.get("title")
        description_text = request.POST.get("description")
        url_1 = request.POST.get("url_1")
        url_2 = request.POST.get("url_2")

        event_title = EventTitle.objects.create(
            title=title_text,
            description=description_text
        )

        Events.objects.create(
            title=event_title,
            url_1=url_1,
            url_2=url_2
        )

        messages.success(request, "Video uploaded successfully!")
        return redirect("upload_video")

    return render(request, "admin/pages/upload_video.html")




@login_required
def video_update(request, id):
    info = get_object_or_404(Events, id=id)

    if request.method == "POST":
        title_text = request.POST.get("title")
        description_text = request.POST.get("description")

        if info.title:
            info.title.title = title_text
            info.title.description = description_text
            info.title.save()
        else:

            event_title = EventTitle.objects.create(
                title=title_text,
                description=description_text
            )
            info.title = event_title

        info.url_1 = request.POST.get("url_1")
        info.url_2 = request.POST.get("url_2")
        info.save()

        messages.success(request, "Updated Successfully")
        return redirect("video_update", id=info.id)

    return render(request, "admin/pages/video_update.html", {"info": info})


@login_required
def video_delete(request, id):
    info = get_object_or_404(Events, id=id)
    if request.method == "POST":
        info.delete()
        messages.success(request,'Deleted Successfully')
        return redirect("AdminEvents")
    return render(request, "admin/pages/events.html")

@login_required
def meeting_create(request):
    if request.method == "POST":
        Events_Meetings.objects.create(
            title=request.POST.get("title"),
            url=request.POST.get("url"),
            description=request.POST.get("description"),
        )
        messages.success(request, "Meeting video uploaded successfully!")
        return redirect("meeting_create")
    
    return render(request, "admin/pages/meeting_create.html", {"action": "Add"})


#vedio_gallary end

@login_required
def meeting_update(request, id):
    meeting = get_object_or_404(Events_Meetings, id=id)

    if request.method == "POST":
        meeting.title = request.POST.get("title")
        meeting.url = request.POST.get("url")
        meeting.description = request.POST.get("description")
        meeting.save()

        messages.success(request, "Meeting video updated successfully!")
        # Use the correct URL name
        return redirect("meeting_video_update", id=meeting.id)

    return render(
        request,
        "admin/pages/meeting_update.html",
        {"meeting": meeting}
    )

@login_required
def meeting_delete(request, id):
    meeting = get_object_or_404(Events_Meetings, id=id)
    if request.method == "POST":
        meeting.delete()
        messages.success(request, "Meeting video deleted successfully!")
        return redirect("AdminEvents")

@login_required
def AdminMedia(request):
    media = PhotoGallery.objects.all()
    context = {
        "media": media
    }
    return render(request, "admin/pages/AminMedia.html", context)

@login_required
def AdminMediaUpload(request):
    if request.method == "POST":
        PhotoGallery.objects.create(
            title=request.POST.get("title"),
            year=request.POST.get("year"),
            description=request.POST.get("description"),
            image=request.FILES.get("image"),
        )
        messages.success(request, "Uploaded successfully")
        
        return redirect("AdminMediaUpload")
    return render(request, "admin/pages/Admin_Media_Upload.html")

@login_required
def AdminMediaUpdate(request, id):
    media = get_object_or_404(PhotoGallery, id=id)

    if request.method == "POST":
        media.title = request.POST.get("title")
        media.year = request.POST.get("year")
        media.description = request.POST.get("description")

        if request.FILES.get("image"):
            media.image = request.FILES.get("image")

        media.save()
        messages.success(request, "Updated successfully")
        return redirect("AdminMediaUpdate", media.id)

    return render(request, "admin/pages/Admin_Media_Update.html", {
        "media": media
    })

@login_required
def AdminMediaDelete(request, id):
    media = get_object_or_404(PhotoGallery, id=id)

    if request.method == "POST":
        media.delete()
        messages.success(request, "Deleted successfully")

    return redirect("AdminMedia")

@login_required
def AdminBlog(request):
    blogs = Blog.objects.all()
    context = {
        "blogs": blogs
    }
    return render(request, "admin/pages/AdminBlog.html", context)

@login_required
def add_blogs(request):
    if request.method == "POST":
        Blog.objects.create(
            title=request.POST.get("title"),
            image=request.FILES.get("image"), 
            date=request.POST.get("date") or None,
            description=request.POST.get("description"),
        )
        messages.success(request, "Blog uploaded successfully")
        return redirect("add_blogs")
    return render(request, "admin/pages/add_blogs.html")

@login_required
def blog_update(request, id):
    blog = get_object_or_404(Blog, id=id)

    if request.method == "POST":
        blog.title = request.POST.get("title")
        blog.date = request.POST.get("date") or None
        blog.description = request.POST.get("description") or None

        if request.FILES.get("image"):
            blog.image = request.FILES.get("image")

        blog.save()
        messages.success(request, "Blog updated successfully")
        return redirect("AdminBlog")

    return render(request, "admin/pages/block_update.html", {"blog": blog})

@login_required
def blog_delete(request, id):
    blog = get_object_or_404(Blog, id=id)
    if request.method == "POST":
        blog.delete()
        messages.success(request, "Blog deleted successfully")
        return redirect("AdminBlog")
    return redirect("AdminBlog")

@login_required
def AdminCampain(request):
    complains = ComplainList.objects.all()
    context = {
        "complains":complains
    }
    return render(request, "admin/pages/complain_list.html", context)

@login_required
def complain_update(request, id):
    complain = get_object_or_404(ComplainList, id=id)

    if request.method == "POST":
        complain.name = request.POST.get("name")
        complain.email = request.POST.get("email")
        complain.phone = request.POST.get("phone") 
        complain.issue = request.POST.get("issue")
        complain.suggetion = request.POST.get("suggetion")

        try:
            complain.full_clean()
            complain.save()

            messages.success(request, "Complain updated successfully")
            return redirect("AdminCampain")

        except ValidationError as e:
            if "phone" in e.message_dict:
                messages.error(request, e.message_dict["phone"][0])
            else:
                messages.error(request, "Invalid data submitted")

    return render(
        request,
        "admin/pages/complain_update.html",
        {"complain": complain}
    )

@login_required
def complain_delete(request, id):
    complain = get_object_or_404(ComplainList, id=id)
    if request.method == "POST":
        complain.delete()
        messages.success(request, "Complain deleted successfully")
        return redirect("AdminCampain")

@login_required
def AdminContact(request):
    contact = Contact_list.objects.all()
    context = {
        'contacts': contact
    }
    return render(request, "admin/pages/contact_list.html", context)


@login_required
def contact_update(request, id):
    contact = get_object_or_404(Contact_list, id=id)

    if request.method == "POST":
        contact.name = request.POST.get("name")
        contact.email = request.POST.get("email")
        contact.address = request.POST.get("address")
        contact.business_name = request.POST.get("business_name")
        contact.message = request.POST.get("message")

        contact.save()
        messages.success(request, "Contact updated successfully!")
        return redirect("AdminContact")

    return render(request, "admin/pages/contact_update.html", {"contact": contact})

@login_required
def contact_delete(request, id):
    contact = get_object_or_404(Contact_list, id=id)

    if request.method == "POST":
        contact.delete()
        messages.success(request, "Contact deleted successfully!")
        return redirect("AdminContact")

    return render(request, "admin/pages/contact_list.html", {"contact": contact})


@login_required
def AdminMembersRules(request):
    membership_rules = MembershipRules.objects.all()
    context = {
         "membership_rules": membership_rules,
    }
    return render(request, "admin/pages/membership_rules.html", context)

@login_required
def AdminMembersRulesAdd(request):
    if request.method == "POST":
        title = request.POST.get("title")
        description = request.POST.get("description")
        rules = request.POST.get("rules")

        MembershipRules.objects.create(
            title=title,
            description=description,
            rules=rules,
        )
        messages.success(request, "Membership rules added successfully!")
        return redirect("AdminMembersRulesAdd")

    return render(request, "admin/pages/add_rules_title_descriptions.html")


@login_required
def AdminMembersRulesUpdate(request, id):
    membership = get_object_or_404(MembershipRules, id=id)

    if request.method == "POST":
        membership.title = request.POST.get("title")
        membership.description = request.POST.get("description")
        membership.rules = request.POST.get("rules")
        membership.save()

        messages.success(
            request,
            "Membership rule updated successfully!"
        )
        return redirect("AdminMembersRulesUpdate", id=id)

    return render(
        request,
        "admin/pages/membership_rules_update.html",
        {"membership": membership}
    )


@login_required
def AdminMembersRulesDelete(request, id):
    membership = get_object_or_404(MembershipRules, id=id)

    if request.method == "POST":
        membership.delete()
        messages.success(request, "Membership Title Descriptions deleted successfully!")
        return redirect("AdminMembersRules")
    

@login_required
def admin_membership_list(request):
    members = Aggregator.objects.all().order_by('company_name')
    comtext = {
        "members" : members
    }
    return render(request, "admin/pages/admin_membership_list.html", comtext)

@login_required
def admin_membership_list_details(request, id):
    members = get_object_or_404(Aggregator, id=id)
    comtext = {
        "members" : members
    }
    return render(request, "admin/pages/admin_membership_list_details.html", comtext)

@login_required
def AdminNews(request):
    newses = News.objects.all()
    return render(request, "admin/pages/admin_news.html", {"newses": newses})

@login_required
def AdminAddNews(request):
    if request.method == "POST":
        News.objects.create(
            title=request.POST.get("title"),
            image=request.FILES.get("image"), 
            date=request.POST.get("date") or None,
            description=request.POST.get("description"),
        )
        messages.success(request, "News uploaded successfully")
        return redirect("AdminAddNews")
    return render(request, "admin/pages/news_upload.html")



@login_required
def AdminUpdateNews(request, id):
    newses = get_object_or_404(News, id=id)

    if request.method == "POST":
        newses.title = request.POST.get("title")
        
        if request.FILES.get("image"):
            newses.image = request.FILES.get("image")
        
        newses.date = request.POST.get("date") or None
        newses.description = request.POST.get("description")
        
        newses.save()

        messages.success(request, "News updated successfully")
        return redirect("news_update", id=newses.id)

    return render(request, "admin/pages/news_update.html", {
        "newses": newses
    })


@login_required
def AdminNewswDelete(request, id):
    news = get_object_or_404(News, id=id)
    if request.method == "POST":
        news.delete()
        messages.success(request, "News deleted successfully!")
        return redirect("AdminNewa")
    


@login_required
def admin_photo_list(request, id):
    album = get_object_or_404(PhotoAlbum, id = id)
    photos = album.photos.all()
    context = {
        'album': album,
        'photos': photos
    }
    return render(request, 'admin/pages/photo_gallery.html', context)

@login_required
def admin_add_photo(request, id):
    album = get_object_or_404(PhotoAlbum, id=id)
    if request.method == 'POST':
        files = request.FILES.getlist('images')

        if files:
            photos = []
            for file in files:
                photo = Photo.objects.create(album=album, image=file)
                photos.append(photo)

            album.banner = random.choice(photos).image
            album.save()

            messages.success(request, "Photos added successfully!")
            return redirect('admin_photo_list', id=album.id)
        else:
            messages.error(request, "Please select at least one image.")

    context = {
        'album': album
    }
    return render(request, 'admin/pages/admin_add_photo.html', context)


@login_required
def admin_update_photo(request, id):
    photo = get_object_or_404(Photo, id=id)
    album = photo.album 

    if request.method == 'POST':
        files = request.FILES.getlist('image')

        if files:
            photo.image = files[0]
            photo.save()

            for file in files[1:]:
                Photo.objects.create(album=photo.album, image=file)

            all_photos = photo.album.photos.all()
            if all_photos:
                photo.album.banner = random.choice(all_photos).image
                photo.album.save()

        messages.success(request, "Photo updated successfully!")
        return redirect('admin_update_photo', id=photo.id)

    return render(request, 'admin/pages/admin_update_photo.html', { 
        'photo': photo, 
        'album': album 
    })

@login_required
def delete_photo(request, id):
    photo = get_object_or_404(Photo, id=id)
    album = photo.album

    if request.method == "POST":
        photo.delete()

        if not album.photos.exists():
            album.delete()
            messages.success(request, "Photo deleted and album removed (no photos left).")
            return redirect("admin_album_list")

        else:
            messages.success(request, "Photo deleted successfully!")
            return redirect("admin_photo_list", album.id)

    


@login_required
def admin_Album_list(request):
    album = PhotoAlbum.objects.all()
    context = {
        'album': album
    }
    return render(request, 'admin/pages/album_list.html', context)

@login_required
def admin_add_album(request):
    if request.method == 'POST':
        title = request.POST.get('title')
        banner = request.FILES.get('banner')

        if title and banner:
            PhotoAlbum.objects.create(title=title, banner=banner)
            messages.success(request, "Album created successfully!")
            return redirect('admin_add_album')
        else:
            messages.error(request, "Please enter a title and select a banner image.")

    return render(request, 'admin/pages/admin_add_album.html')

@login_required
def admin_update_album(request, id):
    album = get_object_or_404(PhotoAlbum, id=id)

    if request.method == 'POST':
        title = request.POST.get('title')
        file = request.FILES.get('banner')

        # Update title
        if title and title.strip() != "":
            album.title = title
            album.save()

        # Update banner image
        if file:
            album.banner = file
            album.save()

        messages.success(request, "Album updated successfully!")
        return redirect('admin_update_album', id=album.id)

    return render(request, 'admin/pages/admin_update_album.html', { 'album': album })

@login_required
def delete_album(request, id):
    photo = get_object_or_404(PhotoAlbum, id=id)

    if request.method == "POST":
        photo.delete()
        messages.success(request, "Album deleted successfully!")
        return redirect("admin_Album_list")



@login_required
def admin_career(request):
    careers = Career.objects.all()
    context = {
        'careers': careers
    }
    return render(request, 'admin/pages/admin_career.html', context)


@login_required
def admin_add_career(request):
    if request.method == "POST":
        title = request.POST.get("title")
        description = request.POST.get("description")

        if title and description:
            Career.objects.create(title=title, description=description) 
            messages.success(request, "Career added successfully!")
            return redirect('admin_add_career')
        else:
            messages.error(request, "Please fill all fields.")
            
    return render(request, 'admin/pages/admin_add_career.html')


@login_required
def admin_update_career(request, id):
    career = get_object_or_404(Career, id=id)

    if request.method == "POST":
        title = request.POST.get("title")
        description = request.POST.get("description")

        if title and description:
            career.title = title
            career.description = description
            career.save()
            
            messages.success(request, "Career updated successfully!")
            return redirect('admin_career')
        else:
            messages.error(request, "Please fill all fields.")

    return render(request, 'admin/pages/admin_update_career.html', {'career': career})

@login_required
def admin_delete_career(request, id):
    career = get_object_or_404(Career, id=id)
    career.delete()
    messages.success(request, "Career deleted successfully!")
    return redirect('admin_career')




@login_required
def meeting_call_list(request, id):

    title = get_object_or_404(MeetingTitle, id=id)
    calls = MeetingCall.objects.filter(title=title).order_by('-created_at')

    context = {
        'title': title,
        'meeting_calls': calls
    }
    return render(request, "admin/pages/meeting_call_list.html", context)

@login_required
def admin_meeting_call(request):
    titles = MeetingTitle.objects.all()
    context = {
        'titles':titles
    }
    return render(request, "admin/pages/admin_meeting_call.html", context)


@login_required
def meeting_call_add(request):
    if request.method == "POST":
        title_text = request.POST.get('title')
        amount = request.POST.get('amount')
        expire_date = request.POST.get('expire_date')
        description = request.POST.get('description')
        image = request.FILES.get('image')

        # 1. Basic Validation to prevent the "Invalid Date" Crash
        if not title_text:
            messages.error(request, "Title is required!")
            return render(request, "admin/pages/meeting_call_add.html")

        if not expire_date or expire_date == "":
            messages.error(request, "Please select a valid expiry date.")
            return render(request, "admin/pages/meeting_call_add.html")

        # 2. Attempt to create the object
        try:
            MeetingTitle.objects.create(
                title=title_text,
                amount=amount,
                expire_date=expire_date,
                description=description,
                image=image
            )
            messages.success(request, "Meeting call added successfully!")
            return redirect('meeting_call_add')
            
        except Exception as e:
            messages.error(request, f"Error saving meeting: {e}")

    return render(request, "admin/pages/meeting_call_add.html")


@login_required
def meeting_call_update(request, id):
    meeting_title = get_object_or_404(MeetingTitle, id=id)

    if request.method == "POST":
        title_text = request.POST.get('title')
        amount = request.POST.get('amount')
        description = request.POST.get('description')
        image = request.FILES.get('image')
        expire_datetime_str = request.POST.get('expire_date')

        if not title_text:
            messages.error(request, "Title is required!")
            return redirect(request.path)

        meeting_title.title = title_text
        meeting_title.amount = amount
        meeting_title.description = description
        if image:
            meeting_title.image = image
        if expire_datetime_str:
            try:
                expire_datetime = datetime.strptime(expire_datetime_str, "%Y-%m-%d %H:%M")
                meeting_title.expire_date = expire_datetime
            except ValueError:
                messages.error(request, "Invalid date or time format!")
                return redirect(request.path)

        meeting_title.save()
        messages.success(request, "Meeting title updated successfully!")
        return redirect('admin_meeting_call')

    context = {
        'meeting': meeting_title 
    }
    return render(request, "admin/pages/meeting_call_update.html", context)

@login_required
def meeting_call_delete(request, id):
    meeting_call = get_object_or_404(MeetingTitle, id=id)
    meeting_call.delete()
    messages.success(request, "Meeting title deleted successfully!")
    return redirect('admin_meeting_call')



@login_required
def call_update(request, id):
    meeting_call = get_object_or_404(MeetingCall, id=id)

    if request.method == "POST":
        title_id = request.POST.get('title_id')
        company_name = request.POST.get('company_name')
        name = request.POST.get('name')
        no_of_person = request.POST.get('no_of_person')
        phone = request.POST.get('phone')
        email = request.POST.get('email')
        payment_method = request.POST.get('payment_method')
        transection_id = request.POST.get('transection_id')

        # Get the title object (ForeignKey)
        if title_id:
            title = get_object_or_404(MeetingTitle, id=title_id)
            meeting_call.title = title

        # Update all other fields
        meeting_call.company_name = company_name
        meeting_call.name = name
        meeting_call.no_of_person = no_of_person
        meeting_call.phone = phone
        meeting_call.email = email
        meeting_call.payment_method = payment_method
        meeting_call.transection_id = transection_id

        meeting_call.save()
        messages.success(request, "Meeting call updated successfully!")

        # ✅ Correct redirect
        return redirect('call_update', id=meeting_call.id)

    # Get all titles for dropdown in template
    titles = MeetingTitle.objects.all().order_by('-id')

    context = {
        'meeting_call': meeting_call,
        'titles': titles
    }
    return render(request, "admin/pages/call_update.html", context)

@login_required
def call_delete(request, id):
    call = get_object_or_404(MeetingCall, id=id)

    call.delete()
    messages.success(request, "Deleted successfully!")

    return redirect('meeting_call_list', call.title.id)

@login_required
def admin_member_registration_list(request):
    registrations = TempMember.objects.all()
    context = {
        'registrations': registrations
    }
    return render(request, "admin/pages/admin_member_registration_list.html", context)


@login_required
def admin_member_registration_list_details(request, id):
    registrations = get_object_or_404(TempMember, id=id)
    context = {
        'registrations': registrations
    }
    return render(request, "admin/pages/admin_member_registration_list_details.html", context)


@login_required
def seo(request):
    seos = Seo.objects.all() 
    context = {
        'seos': seos
    }
    return render(request, "admin/pages/seo.html", context)

@login_required
def edit_seo(request, id):
    seo = get_object_or_404(Seo, id=id)

    if request.method == "POST":
        seo.page_name = request.POST.get("page_name")
        seo.meta_title = request.POST.get("meta_title")
        seo.meta_description = request.POST.get("meta_description")
        seo.meta_keywords = request.POST.get("meta_keywords")
        seo.meta_url = request.POST.get("meta_url")

        # Handle image upload
        if request.FILES.get("meta_image"):
            seo.meta_image = request.FILES.get("meta_image")

        seo.save()
        messages.success(request, "SEO updated successfully")
        return redirect("edit_seo", seo.id)  
    context = {
        "seo": seo
    }
    return render(request, "admin/pages/edit_seo.html", context)


@login_required
def add_seo(request):

    if request.method == "POST":
        page_name = request.POST.get("page_name")

        # Prevent duplicate page
        if Seo.objects.filter(page_name=page_name).exists():
            messages.error(request, "Page already exists")
            return redirect("add_seo")

        seo = Seo(
            page_name=page_name,
            meta_title=request.POST.get("meta_title"),
            meta_description=request.POST.get("meta_description"),
            meta_keywords=request.POST.get("meta_keywords"),
            meta_url=request.POST.get("meta_url"),
            meta_image=request.FILES.get("meta_image")
        )

        seo.save()

        messages.success(request, "SEO added successfully")
        return redirect("add_seo")  

    return render(request, "admin/pages/add_seo.html")

@login_required
def accept(request, id):
    temp_member = get_object_or_404(TempMember, id=id)
    
    try:
        with transaction.atomic():
            user = User.objects.create_user(
                email=temp_member.email,
                user_type=2
            )
            user.password = temp_member.password
            user.save()

            Aggregator.objects.create(
                user=user,
                name=temp_member.person_name,
                company_name=temp_member.company_name,
                designation=temp_member.designation,
                mobile=temp_member.mobile,
                phone=temp_member.phone,
                is_aggregator=temp_member.is_aggregator,
                brtc_licence_no=temp_member.brtc_licence_no,
                appoinment_letter=temp_member.appoinment_letter,
                cv=temp_member.cv,
                address=temp_member.address,
                n_id = temp_member.n_id,
            )

            temp_member.delete()
            
            messages.success(request, f"Member {user.email} has been approved.")

    except Exception as e:
        messages.error(request, f"An error occurred: {str(e)}")
        
    return redirect('admin_member_registration_list')

@login_required
def reject(request, id):
    temp_member = get_object_or_404(TempMember, id=id)

    temp_member.delete()
    messages.success(request, "Rejected successfully!")

    return redirect('admin_member_registration_list')


# admin_view end


#common for all
def contact_submit(request):
   if request.method == "POST":
        Contact_list.objects.create(
            name=request.POST.get("name"),
            email=request.POST.get("email"),
            address=request.POST.get("address"),
            message=request.POST.get("message"),
        )


        messages.success(request, "Thank you! Your message has been sent successfully.")
        return redirect(request.META.get("HTTP_REFERER", "/"))
   
   
   
def check_email(request):
    email = request.GET.get('email', '').strip()
    exists = User.objects.filter(email=email).exists() or TempMember.objects.filter(email=email).exists()
    return JsonResponse({'exists': exists})


def check_phone(request):
    mobile = normalize_phone(request.GET.get('mobile', ''))
    phone_exists = Aggregator.objects.filter(mobile=mobile).exists() or TempMember.objects.filter(mobile=mobile).exists()
    return JsonResponse({'phone_exists': phone_exists})








#profile